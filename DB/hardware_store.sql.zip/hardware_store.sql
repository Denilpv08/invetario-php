-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Servidor: localhost
-- Tiempo de generación: 26-10-2024 a las 02:53:27
-- Versión del servidor: 8.0.17
-- Versión de PHP: 7.3.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `hardware_store`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cotizaciones`
--

CREATE TABLE `cotizaciones` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `producto_id` int(11) DEFAULT NULL,
  `cantidad` int(11) DEFAULT NULL,
  `precio_total` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Volcado de datos para la tabla `cotizaciones`
--

INSERT INTO `cotizaciones` (`id`, `user_id`, `producto_id`, `cantidad`, `precio_total`) VALUES
(1, 1, 1, 2, '540.00'),
(2, 1, 1, 2, '540.00'),
(3, 1, 2, 3, '54.00'),
(4, 1, 3, 3, '5.40'),
(5, 1, 4, 2, '774.00'),
(6, 1, 4, 2, '774.00'),
(7, 1, 3, 4, '7.20'),
(8, 1, 2, 4, '72.00'),
(9, 1, 1, 2, '540.00'),
(10, 1, 4, 1, '387.00'),
(11, 1, 5, 1, '90.00'),
(12, 1, 2, 5, '104.50'),
(13, 1, 3, 5, '104.50');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `productos`
--

CREATE TABLE `productos` (
  `id` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `descripcion` text,
  `precio` decimal(10,2) NOT NULL,
  `stock` int(11) NOT NULL,
  `imagen` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Volcado de datos para la tabla `productos`
--

INSERT INTO `productos` (`id`, `nombre`, `descripcion`, `precio`, `stock`, `imagen`) VALUES
(1, 'Sierra Electrica', 'Lo que tienes que saber de este producto\r\nVoltaje: 110V\r\nRecomendada para cortar corte de madera.\r\nTiene una potencia de 1400W.\r\nSu velocidad máxima de rotación es de 5300rpm.\r\nEl diámetro del disco es de 184mm.\r\nLa profundidad de corte de 45º es 46mm.\r\nLa profundidad de corte de 90º es 60mm.\r\nTiene botón de bloqueo de disco.\r\nMide 26cm de largo, 29cm de ancho y 24cm de alto.\r\nPesa 4kg.\r\nTrae: disco de corte de 18 dientes con carburo de tungsteno.\r\nPerfecta para hacer cortes precisos.\r\nUna herramienta versátil.', '300.00', 50, 'Sierra.png'),
(2, 'Hombre solos', 'Lo que tienes que saber de este producto\r\nApertura de mordaza: 10\".\r\nEs autoajustable.', '20.00', 150, 'Hombre solos.png'),
(3, 'Cortadora De Plasma', 'Cortadora de plasma Inversor de aire Máquina de corte por plasma Máquina de soldadura portátil digital con pantalla LCD y accesorios Herramientas Modelo HBC5500', '2.00', 35, 'Corta plasma.png'),
(4, 'Polichadora De 7 Elite', 'Características\r\nPoderoso motor de 1.400W de larga duración.\r\nSwitch de velocidad variable.\r\nPomo de microfibra que garantiza trabajos brillantes.\r\nPeso: 3,0 Kg\r\n12cm Alto x 20cm Ancho x 48cm Largo', '430.00', 65, 'Polichadora.png'),
(5, 'Pistola de pintura ', 'o que tienes que saber de este producto\r\nPinte de forma más rápida y eficiente.', '100.00', 100, 'Pistola de pintura.png'),
(491569, 'Destornillador Eléctrico ', 'Un destornillador adaptable para cualquier tipo de tonillo ', '120.00', 70, 'Screenshot_153.png');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `tipo_cliente` enum('Permanente','Periódico','Casual','Nuevo') NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Volcado de datos para la tabla `users`
--

INSERT INTO `users` (`id`, `nombre`, `email`, `tipo_cliente`, `password`) VALUES
(1, 'Denilson Prescott', 'denilpv@gmail.com', 'Periódico', '1234567');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `cotizaciones`
--
ALTER TABLE `cotizaciones`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `producto_id` (`producto_id`);

--
-- Indices de la tabla `productos`
--
ALTER TABLE `productos`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `cotizaciones`
--
ALTER TABLE `cotizaciones`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT de la tabla `productos`
--
ALTER TABLE `productos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=491570;

--
-- AUTO_INCREMENT de la tabla `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `cotizaciones`
--
ALTER TABLE `cotizaciones`
  ADD CONSTRAINT `cotizaciones_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `cotizaciones_ibfk_2` FOREIGN KEY (`producto_id`) REFERENCES `productos` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
